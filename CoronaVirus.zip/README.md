# Pacman - Pygame

A remake of the classic Pac-Man arcade game using Python and Pygame. Developed for Grade 10 Computer Science.

Pac-Man: https://en.wikipedia.org/wiki/Pac-Man


## Controls

Use the arrow keys for navigation.


## Technologies

Developed using **Python 2.7** and **Pygame 1.9.1**.


## Pygame

Main: http://www.pygame.org

Download: http://www.pygame.org/download.shtml
