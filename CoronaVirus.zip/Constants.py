WINDOWSIZE = (650, 600)
FPS = 60  # frames per second
YELLOW = (255, 255, 0)
